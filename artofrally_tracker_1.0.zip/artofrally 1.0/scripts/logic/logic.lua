function has(item, amount)
	--print(string.format("Looking for item: %s",item))
    local count = Tracker:ProviderCountForCode(item)
    if not amount then
        return count > 0
    else
        amount = tonumber(amount)
        return count >= amount
    end
end

function can_group_2()
    return has("promo_1") and (has("the_esky_v1") or has("the_meanie") or has("la_montaine") or has("das_220") or has("das_119i") or has("le_gorde") or has("la_regina"))
end

function can_group_3()
    return has("promo_2") and (has("the_esky_v2") or has("il_nonno_313") or has("the_rotary_3") or has("la_wedge") or has("il_cavallo_803") or has("das_119e") or has("la_hepta") or has("the_pebble_v1") or has("the_pebble_v2") or has("the_zetto"))
end

function can_group_4()
    return has("promo_3") and (has("le_cinq") or has("das_whip") or has("turbo_brick") or has("das_uberwhip") or has("the_cozzie_sr5") or has("the_original") or has("la_super_montaine") or has("la_longana") or has("the_gazelle"))
end

function can_group_b()
    return has("promo_4") and (has("the_4r6") or has("le_502") or has("das_hammer_v1") or has("das_hammer_v2") or has("il_gorilla_4s") or has("the_cozzie_sr2") or has("the_cozzie_sr71") or has("the_rotary_b7") or has("das_hammer_v3") or has("il_monster") or has("il_cavallo_882") or has("le_cinq_b") or has("das_uberspeedvan") or has("the_king_of_africa") or has("das_559") or has("the_hyena"))
end

function can_group_s()
    return has("promo_5") and (has("das_eibenhammer") or has("the_rotary_s7") or has("the_umibozu") or has("il_gorilla_e1") or has("le_504") or has("il_gorilla_e2") or has("das_superbaus") or has("the_t22"))
end

function can_group_a()
    return has("promo_6") and (has("il_gorillona") or has("the_fujin") or has("the_liftback") or has("the_max_attack") or has("the_cozzie_90"))
end