Tracker:AddLocations("locations/free_roam/korkatti_lakes.json")
Tracker:AddLocations("locations/free_roam/san_pietro_island.json")
Tracker:AddLocations("locations/free_roam/kanto_mountains.json")
Tracker:AddLocations("locations/free_roam/gimsoymyrene.json")
Tracker:AddLocations("locations/free_roam/mara_simba.json")
Tracker:AddLocations("locations/free_roam/mannebach.json")
Tracker:AddLocations("locations/free_roam/kabeana_island.json")

Tracker:AddLocations("locations/career/career.json")
